function translate(input)
{
    if(input != null) return true;
    else return false;
}